<?php
declare(strict_types=1);

namespace App\Providers;

final class VerificationException extends \RuntimeException
{
    public function __construct(public readonly string $reason, string $message)
    {
        parent::__construct($message);
    }
}
